﻿from __future__ import annotations

import argparse
import math
import re
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import MiniBatchKMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import silhouette_score
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import Normalizer


DEFAULT_INDEX_CSV = Path("data/pf_operacoes_index.csv")
DEFAULT_CONTENT_CSV = Path("data/pf_operacoes_conteudos.csv")
DEFAULT_OUTPUT_DIR = Path("data/analise_qualitativa")


def fold_text(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return ascii_text.lower()

PORTUGUESE_STOPWORDS = {
    "a", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles", "aquilo", "as", "ate",
    "com", "como", "contra", "da", "das", "de", "dela", "dele", "deles", "demais", "depois",
    "do", "dos", "e", "ela", "elas", "ele", "eles", "em", "entre", "era", "eram", "essa",
    "essas", "esse", "esses", "esta", "estao", "estar", "estas", "estava", "este", "estes",
    "foi", "foram", "ha", "isso", "isto", "ja", "la", "lhe", "lhes", "mais", "mas", "mesmo",
    "na", "nas", "nao", "nem", "no", "nos", "nossa", "nosso", "nossos", "num", "numa", "o",
    "os", "ou", "para", "pela", "pelas", "pelo", "pelos", "por", "qual", "quando", "que",
    "quem", "se", "sem", "ser", "seu", "seus", "sido", "sob", "sobre", "sua", "suas", "tal",
    "tambem", "te", "tem", "tendo", "ter", "teve", "tipo", "toda", "todas", "todo", "todos",
    "um", "uma", "umas", "uns", "vos", "Ã ", "Ã s", "Ã©",
    "policia", "federal", "pf", "operacao", "operacoes", "noticia", "noticias"
}

CRIME_PATTERNS = {
    "lavagem_dinheiro": [
        "lavagem de dinheiro", "lavagem de capitais", "ocultacao de bens",
        "ocultaÃ§Ã£o de bens", "evasao de divisas", "evasÃ£o de divisas"
    ],
    "trafico_drogas": [
        "trafico de drogas", "trÃ¡fico de drogas", "entorpecentes", "maconha",
        "cocaina", "cocaÃ­na", "crack"
    ],
    "trafico_armas": [
        "trafico de armas", "trÃ¡fico de armas", "armas de fogo", "municoes", "muniÃ§Ãµes"
    ],
    "crimes_ambientais": [
        "crime ambiental", "crimes ambientais", "garimpo ilegal", "desmatamento",
        "pesca ilegal", "extraÃ§Ã£o ilegal", "extracao ilegal", "madeira ilegal", "ibama", "icmbio"
    ],
    "crime_eleitoral": [
        "crime eleitoral", "crimes eleitorais", "sufragio", "sufrÃ¡gio", "compra de votos"
    ],
    "corrupcao_desvio": [
        "corrupcao", "corrupÃ§Ã£o", "desvio de recursos", "desvio de verbas",
        "licitacao", "licitaÃ§Ã£o", "fraude em licitacao", "fraude em licitaÃ§Ã£o",
        "peculato", "prefeitura"
    ],
    "abuso_sexual_infantil": [
        "abuso sexual infantojuvenil", "abuso sexual de criancas", "abuso sexual de crianÃ§as",
        "pornografia infantil", "exploracao sexual infantil", "exploraÃ§Ã£o sexual infantil",
        "pedofilia"
    ],
    "contrabando_descaminho": [
        "contrabando", "descaminho", "cigarros falsificados", "cigarro falsificado",
        "mercadoria estrangeira", "importacao irregular", "importaÃ§Ã£o irregular"
    ],
    "fraude_bancaria_cibernetica": [
        "fraude bancaria", "fraude bancÃ¡ria", "fraudes bancarias", "fraudes bancÃ¡rias",
        "golpe", "crime cibernetico", "crime cibernÃ©tico", "phishing", "internet banking"
    ],
    "trabalho_escravo_trafico_pessoas": [
        "trabalho escravo", "trabalho analogo ao de escravo", "trabalho anÃ¡logo ao de escravo",
        "trafico de pessoas", "trÃ¡fico de pessoas", "condicoes degradantes", "condiÃ§Ãµes degradantes"
    ],
    "organizacao_criminosa": [
        "organizacao criminosa", "organizaÃ§Ã£o criminosa", "facÃ§Ã£o criminosa", "associacao criminosa",
        "associaÃ§Ã£o criminosa", "milicia", "milÃ­cia"
    ],
    "falsidade_documental": [
        "falsidade ideologica", "falsidade ideolÃ³gica", "documento falso", "passaporte falso",
        "moeda falsa", "certidao falsa", "certidÃ£o falsa"
    ],
}

MODUS_PATTERNS = {
    "busca_apreensao": ["busca e apreensao", "busca e apreensÃ£o", "mandado de busca", "mandados de busca"],
    "prisao": ["prisao preventiva", "prisÃ£o preventiva", "prisao temporaria", "prisÃ£o temporÃ¡ria", "mandado de prisÃ£o", "flagrante"],
    "bloqueio_bens": ["bloqueio de bens", "sequestro de bens", "indisponibilidade de bens", "bloqueio judicial"],
    "fiscalizacao": ["fiscalizacao", "fiscalizaÃ§Ã£o", "inspecao", "inspeÃ§Ã£o", "vistoria"],
    "atuacao_online": ["internet", "rede social", "whatsapp", "telegram", "site", "online"],
    "cooperacao_interagencias": ["ficco", "ibama", "receita federal", "funai", "prf", "cgU", "controladoria-geral da uniao", "gaeco", "forca integrada", "forÃ§a integrada"],
    "fronteira_transnacional": ["fronteira", "paraguai", "bolivia", "bolÃ­via", "argentina", "internacional", "transnacional"],
    "resgate_vitimas": ["resgate", "vitimas", "vÃ­timas", "trabalhadores resgatados", "pessoas resgatadas"],
    "desarticulacao_rede": ["desarticular", "desarticulaÃ§Ã£o", "esquema criminoso", "quadrilha", "rede criminosa"],
    "combate_financeiro": ["movimentacao financeira", "movimentaÃ§Ã£o financeira", "contas bancarias", "contas bancÃ¡rias", "sigilo bancario", "sigilo bancÃ¡rio"],
}

BRAZIL_STATES = [
    {"uf": "AC", "state": "Acre", "capital": "Rio Branco", "lat": -9.97499, "lon": -67.8243},
    {"uf": "AL", "state": "Alagoas", "capital": "Maceio", "lat": -9.64985, "lon": -35.70895},
    {"uf": "AP", "state": "Amapa", "capital": "Macapa", "lat": 0.03493, "lon": -51.0694},
    {"uf": "AM", "state": "Amazonas", "capital": "Manaus", "lat": -3.11903, "lon": -60.0217},
    {"uf": "BA", "state": "Bahia", "capital": "Salvador", "lat": -12.9718, "lon": -38.5011},
    {"uf": "CE", "state": "Ceara", "capital": "Fortaleza", "lat": -3.73186, "lon": -38.5267},
    {"uf": "DF", "state": "Distrito Federal", "capital": "Brasilia", "lat": -15.7797, "lon": -47.9297},
    {"uf": "ES", "state": "Espirito Santo", "capital": "Vitoria", "lat": -20.3155, "lon": -40.3128},
    {"uf": "GO", "state": "Goias", "capital": "Goiania", "lat": -16.6864, "lon": -49.2643},
    {"uf": "MA", "state": "Maranhao", "capital": "Sao Luis", "lat": -2.53874, "lon": -44.2825},
    {"uf": "MT", "state": "Mato Grosso", "capital": "Cuiaba", "lat": -15.6014, "lon": -56.0974},
    {"uf": "MS", "state": "Mato Grosso do Sul", "capital": "Campo Grande", "lat": -20.4697, "lon": -54.6201},
    {"uf": "MG", "state": "Minas Gerais", "capital": "Belo Horizonte", "lat": -19.9167, "lon": -43.9345},
    {"uf": "PA", "state": "Para", "capital": "Belem", "lat": -1.45583, "lon": -48.5044},
    {"uf": "PB", "state": "Paraiba", "capital": "Joao Pessoa", "lat": -7.11532, "lon": -34.861},
    {"uf": "PR", "state": "Parana", "capital": "Curitiba", "lat": -25.4284, "lon": -49.2733},
    {"uf": "PE", "state": "Pernambuco", "capital": "Recife", "lat": -8.05389, "lon": -34.8811},
    {"uf": "PI", "state": "Piaui", "capital": "Teresina", "lat": -5.08917, "lon": -42.8019},
    {"uf": "RJ", "state": "Rio de Janeiro", "capital": "Rio de Janeiro", "lat": -22.9068, "lon": -43.1729},
    {"uf": "RN", "state": "Rio Grande do Norte", "capital": "Natal", "lat": -5.79448, "lon": -35.211},
    {"uf": "RS", "state": "Rio Grande do Sul", "capital": "Porto Alegre", "lat": -30.0346, "lon": -51.2177},
    {"uf": "RO", "state": "Rondonia", "capital": "Porto Velho", "lat": -8.76077, "lon": -63.8999},
    {"uf": "RR", "state": "Roraima", "capital": "Boa Vista", "lat": 2.82384, "lon": -60.6753},
    {"uf": "SC", "state": "Santa Catarina", "capital": "Florianopolis", "lat": -27.5949, "lon": -48.5482},
    {"uf": "SP", "state": "Sao Paulo", "capital": "Sao Paulo", "lat": -23.5505, "lon": -46.6333},
    {"uf": "SE", "state": "Sergipe", "capital": "Aracaju", "lat": -10.9472, "lon": -37.0731},
    {"uf": "TO", "state": "Tocantins", "capital": "Palmas", "lat": -10.184, "lon": -48.3336},
]

STATE_LOOKUP = {item["uf"]: item for item in BRAZIL_STATES}
STATE_NAME_TO_UF = {item["state"].lower(): item["uf"] for item in BRAZIL_STATES}
STATE_TAG_TO_UF = {
    unicodedata.normalize("NFKD", item["state"]).encode("ascii", "ignore").decode("ascii").lower(): item["uf"]
    for item in BRAZIL_STATES
}
STATE_TAG_TO_UF.update({item["uf"].lower(): item["uf"] for item in BRAZIL_STATES})
GEO_PHRASES = sorted(
    {item["state"].lower() for item in BRAZIL_STATES}
    | {item["capital"].lower() for item in BRAZIL_STATES}
    | {"brasil", "paraguai", "argentina", "bolivia", "uruguai", "amazonia"},
    key=len,
    reverse=True,
)
UF_PATTERN = "|".join(sorted([item["uf"].lower() for item in BRAZIL_STATES]))
DATALINE_REGEX = re.compile(r"\b[\w' -]{2,60}/([A-Z]{2})\b")
TITLE_STATE_PATTERNS = {
    item["uf"]: re.compile(rf"\b{re.escape(fold_text(item['state']))}\b")
    for item in BRAZIL_STATES
}
TITLE_STATE_PATTERNS["SP"] = re.compile(r"\bsao paulo\b(?!\s+de\b)")
TITLE_STATE_PATTERNS["PA"] = re.compile(r"\bestado do para\b|\bestado do parÃ¡\b")
# Override the broad geography patterns above with tighter, location-oriented rules.
DATALINE_REGEX = re.compile(r"\b[\w' -]{2,60}/([A-Z]{2})\b")
TITLE_STATE_PATTERNS = {
    item["uf"]: re.compile(rf"\b{re.escape(fold_text(item['state']))}\b")
    for item in BRAZIL_STATES
}
TITLE_STATE_PATTERNS["SP"] = re.compile(r"\bsao paulo\b(?!\s+de\b)")
TITLE_STATE_PATTERNS["PA"] = re.compile(r"\bestado do para\b")


@dataclass
class AnalysisArtifacts:
    corpus: pd.DataFrame
    neighbors: pd.DataFrame
    recurring_pairs: pd.DataFrame
    cluster_summary: pd.DataFrame
    temporal_summary: pd.DataFrame
    crime_summary: pd.DataFrame
    modus_summary: pd.DataFrame
    semantic_series: pd.DataFrame


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analise qualitativa e semantica das noticias de operacoes da PF."
    )
    parser.add_argument("--index-csv", type=Path, default=DEFAULT_INDEX_CSV)
    parser.add_argument("--content-csv", type=Path, default=DEFAULT_CONTENT_CSV)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--neighbors", type=int, default=6)
    parser.add_argument("--series-threshold", type=float, default=0.70)
    parser.add_argument("--random-state", type=int, default=42)
    return parser.parse_args()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def read_markdown_text(path_value: str) -> str:
    path = Path(path_value)
    return path.read_text(encoding="utf-8")


def strip_markdown(text: str) -> str:
    text = re.sub(r"`{1,3}.*?`{1,3}", " ", text, flags=re.DOTALL)
    text = re.sub(r"\[(.*?)\]\((.*?)\)", r"\1", text)
    text = re.sub(r"[*_>#-]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalize_label(value: str) -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    return cleaned or "sem_rotulo"


def fold_text(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return ascii_text.lower()


def semantic_preprocess(text: str) -> str:
    original = re.sub(r"\b[\w' -]{2,60}/[A-Z]{2}\b", " ", text)
    folded = fold_text(original)
    for phrase in GEO_PHRASES:
        folded = re.sub(rf"\b{re.escape(phrase)}\b", " ", folded)
    folded = re.sub(rf"\b(?:{UF_PATTERN})\b", " ", folded)
    folded = re.sub(r"\d+", " ", folded)
    folded = re.sub(r"\s+", " ", folded)
    return folded.strip()


def parse_datetime(value: str | float | None) -> pd.Timestamp:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return pd.NaT
    text = str(value).strip()
    if not text:
        return pd.NaT
    return pd.to_datetime(text, format="%d/%m/%Y %Hh%M", errors="coerce")


def extract_state_mentions(
    title: str,
    subtitle: str,
    tags: str,
    markdown_text: str,
) -> list[str]:
    found_ufs: set[str] = set()
    headline_text = fold_text(f"{title} {subtitle}")
    lead_text = markdown_text[:1200]

    for raw_tag in [part.strip() for part in str(tags).split("|") if part.strip()]:
        tag_key = fold_text(raw_tag)
        uf = STATE_TAG_TO_UF.get(tag_key)
        if uf:
            found_ufs.add(uf)

    for uf, pattern in TITLE_STATE_PATTERNS.items():
        if pattern.search(headline_text):
            found_ufs.add(uf)

    for match in DATALINE_REGEX.findall(lead_text):
        uf = match.upper()
        if uf in STATE_LOOKUP:
            found_ufs.add(uf)

    return sorted(found_ufs)


def ufs_to_states(ufs: list[str]) -> list[str]:
    return [STATE_LOOKUP[uf]["state"] for uf in ufs if uf in STATE_LOOKUP]


def extract_operation_name(title: str) -> str | None:
    folded = fold_text(title)
    match = re.search(r"operacao\s+([a-z0-9\s-]{2,60})", folded)
    if not match:
        return None

    stop_tokens = {"em", "no", "na", "nos", "nas", "contra", "para", "com", "do", "da", "de", "e"}
    raw_tokens = match.group(1).split()
    if not raw_tokens or raw_tokens[0] in stop_tokens:
        return None

    tokens = []
    for token in raw_tokens:
        if token in stop_tokens and tokens:
            break
        if token in {"fase", "fases"} and tokens:
            break
        token = token.strip("-")
        if not token:
            continue
        tokens.append(token)
        if len(tokens) >= 3:
            break

    if tokens:
        return " ".join(token.capitalize() for token in tokens)
    return None


def keyword_hits(text: str, patterns: dict[str, list[str]]) -> list[str]:
    lowered = fold_text(text)
    hits = []
    for label, keywords in patterns.items():
        if any(fold_text(keyword) in lowered for keyword in keywords):
            hits.append(label)
    return hits


def load_corpus(index_csv: Path, content_csv: Path) -> pd.DataFrame:
    index_df = pd.read_csv(index_csv)
    content_df = pd.read_csv(content_csv)
    content_df = content_df.copy()
    content_df["status"] = content_df["status"].fillna("")
    content_df["markdown_path"] = content_df["markdown_path"].fillna("")
    content_df = content_df.loc[content_df["status"].eq("ok") & content_df["markdown_path"].ne("")].copy()
    content_df["markdown_exists"] = content_df["markdown_path"].map(lambda value: Path(value).exists())
    missing_markdown = int((~content_df["markdown_exists"]).sum())
    if missing_markdown:
        print(f"[analysis] ignorando {missing_markdown} registros com markdown ausente no manifesto.")
    content_df = content_df.loc[content_df["markdown_exists"]].drop(columns=["markdown_exists"])

    df = index_df.merge(content_df, on="link", how="inner", validate="one_to_one")
    if df.empty:
        raise ValueError("Nenhum artigo com status 'ok' e markdown disponivel foi encontrado para analise.")

    df["markdown_text"] = df["markdown_path"].map(read_markdown_text)
    df["texto_limpo"] = df["markdown_text"].map(strip_markdown)
    df["texto_busca"] = (
        df["titulo"].fillna("") + " "
        + df["subtitulo"].fillna("") + " "
        + df["tags"].fillna("").str.replace("|", " ", regex=False) + " "
        + df["texto_limpo"].fillna("")
    ).str.strip()
    df["texto_busca_normalizado"] = df["texto_busca"].map(fold_text)
    df["texto_sem_geo"] = df["texto_busca"].map(semantic_preprocess)
    df["texto_ponderado"] = (
        (df["titulo"].fillna("") + " ") * 3
        + (df["subtitulo"].fillna("") + " ") * 2
        + df["texto_sem_geo"].fillna("")
    ).str.strip()
    df["data_publicacao_dt"] = df["publicado_em_extraido"].map(parse_datetime)
    df["ano"] = df["data_publicacao_dt"].dt.year
    df["mes"] = df["data_publicacao_dt"].dt.month
    df["ano_mes"] = df["data_publicacao_dt"].dt.to_period("M").astype(str)
    df["nome_operacao"] = df["titulo"].fillna("").map(extract_operation_name)
    df["crime_labels"] = df["texto_busca"].map(lambda x: keyword_hits(x, CRIME_PATTERNS))
    df["modus_labels"] = df["texto_busca"].map(lambda x: keyword_hits(x, MODUS_PATTERNS))
    df["ufs_mencionadas"] = df.apply(
        lambda row: extract_state_mentions(
            title=row["titulo"],
            subtitle=row["subtitulo"],
            tags=row["tags"],
            markdown_text=row["markdown_text"],
        ),
        axis=1,
    )
    df["estados_mencionados"] = df["ufs_mencionadas"].map(ufs_to_states)
    return df


def build_semantic_space(texts: pd.Series, random_state: int) -> tuple[TfidfVectorizer, np.ndarray, np.ndarray]:
    vectorizer = TfidfVectorizer(
        lowercase=False,
        preprocessor=semantic_preprocess,
        stop_words=sorted(PORTUGUESE_STOPWORDS),
        ngram_range=(1, 2),
        min_df=3,
        max_df=0.80,
        max_features=40000,
        token_pattern=r"(?u)\b[a-z0-9-]{2,}\b",
    )
    tfidf_matrix = vectorizer.fit_transform(texts)
    n_components = min(160, max(2, tfidf_matrix.shape[1] - 1))
    svd = TruncatedSVD(n_components=n_components, random_state=random_state)
    reduced = svd.fit_transform(tfidf_matrix)
    reduced = Normalizer(copy=False).fit_transform(reduced)
    return vectorizer, tfidf_matrix, reduced


def choose_cluster_count(embeddings: np.ndarray, random_state: int) -> int:
    candidate_ks = [12, 16, 20, 24, 28, 32]
    sample_size = min(2000, len(embeddings))
    if sample_size < 200:
        return 12

    rng = np.random.default_rng(random_state)
    sample_idx = rng.choice(len(embeddings), size=sample_size, replace=False)
    sample = embeddings[sample_idx]
    best_k = candidate_ks[0]
    best_score = -1.0

    for k in candidate_ks:
        model = MiniBatchKMeans(
            n_clusters=k,
            random_state=random_state,
            batch_size=1024,
            n_init=10,
        )
        labels = model.fit_predict(sample)
        score = silhouette_score(sample, labels, metric="cosine")
        if score > best_score:
            best_score = score
            best_k = k

    return best_k


def assign_clusters(embeddings: np.ndarray, random_state: int) -> np.ndarray:
    n_clusters = choose_cluster_count(embeddings, random_state=random_state)
    model = MiniBatchKMeans(
        n_clusters=n_clusters,
        random_state=random_state,
        batch_size=1024,
        n_init=20,
    )
    return model.fit_predict(embeddings)


def top_terms_by_cluster(
    tfidf_matrix,
    vectorizer: TfidfVectorizer,
    labels: np.ndarray,
    top_n: int = 10,
) -> dict[int, list[str]]:
    terms = np.array(vectorizer.get_feature_names_out())
    results: dict[int, list[str]] = {}
    geo_terms = {normalize_label(fold_text(item["state"])) for item in BRAZIL_STATES}
    geo_terms |= {normalize_label(fold_text(item["capital"])) for item in BRAZIL_STATES}
    geo_terms |= {item["uf"].lower() for item in BRAZIL_STATES}

    for cluster_id in sorted(set(labels)):
        idx = np.where(labels == cluster_id)[0]
        centroid = np.asarray(tfidf_matrix[idx].mean(axis=0)).ravel()
        ordered = centroid.argsort()[::-1]
        chosen: list[str] = []
        for term_index in ordered:
            term = str(terms[term_index])
            term_key = normalize_label(term)
            if term_key in geo_terms:
                continue
            if any(token in geo_terms for token in term.split()):
                continue
            chosen.append(term)
            if len(chosen) >= top_n:
                break
        results[int(cluster_id)] = chosen
    return results


def nearest_neighbors(df: pd.DataFrame, embeddings: np.ndarray, n_neighbors: int) -> pd.DataFrame:
    model = NearestNeighbors(metric="cosine", algorithm="brute", n_neighbors=n_neighbors)
    model.fit(embeddings)
    distances, indices = model.kneighbors(embeddings)

    rows: list[dict[str, object]] = []
    for source_idx in range(len(df)):
        for rank in range(1, n_neighbors):
            target_idx = int(indices[source_idx, rank])
            similarity = float(1 - distances[source_idx, rank])
            source_date = df.iloc[source_idx]["data_publicacao_dt"]
            target_date = df.iloc[target_idx]["data_publicacao_dt"]
            rows.append(
                {
                    "source_link": df.iloc[source_idx]["link"],
                    "source_titulo": df.iloc[source_idx]["titulo"],
                    "source_data": source_date,
                    "target_link": df.iloc[target_idx]["link"],
                    "target_titulo": df.iloc[target_idx]["titulo"],
                    "target_data": target_date,
                    "rank": rank,
                    "cosine_similarity": round(similarity, 6),
                    "source_cluster_id": int(df.iloc[source_idx]["cluster_id"]),
                    "target_cluster_id": int(df.iloc[target_idx]["cluster_id"]),
                    "source_operation_name": df.iloc[source_idx]["nome_operacao"],
                    "target_operation_name": df.iloc[target_idx]["nome_operacao"],
                    "same_cluster": bool(df.iloc[source_idx]["cluster_id"] == df.iloc[target_idx]["cluster_id"]),
                    "gap_days": abs((target_date - source_date).days) if pd.notna(source_date) and pd.notna(target_date) else np.nan,
                }
            )
    return pd.DataFrame(rows)


class UnionFind:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra = self.find(a)
        rb = self.find(b)
        if ra == rb:
            return
        if self.size[ra] < self.size[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        self.size[ra] += self.size[rb]


def semantic_series(df: pd.DataFrame, recurring_pairs_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    link_to_idx = {link: idx for idx, link in enumerate(df["link"].tolist())}
    uf = UnionFind(len(df))

    for _, row in recurring_pairs_df.iterrows():
        uf.union(link_to_idx[row["source_link"]], link_to_idx[row["target_link"]])

    component_map: dict[int, list[int]] = defaultdict(list)
    for idx in range(len(df)):
        component_map[uf.find(idx)].append(idx)

    assignments = []
    summaries = []
    component_id = 0
    for members in sorted(component_map.values(), key=len, reverse=True):
        if len(members) < 2:
            continue
        component_id += 1
        subset = df.iloc[members].sort_values("data_publicacao_dt")
        title_examples = subset["titulo"].head(3).tolist()
        operation_names = [name for name in subset["nome_operacao"].dropna().tolist() if name]
        crime_labels = Counter(label for labels in subset["crime_labels"] for label in labels)
        cluster_modes = subset["cluster_id"].mode().tolist()[:3]
        series_label = build_series_label(operation_names, crime_labels, title_examples, cluster_modes)
        series_group_key = build_series_group_key(operation_names, crime_labels, series_label)

        for member_idx in members:
            assignments.append(
                {
                    "link": df.iloc[member_idx]["link"],
                    "semantic_series_id": component_id,
                    "titulo": df.iloc[member_idx]["titulo"],
                    "data_publicacao_dt": df.iloc[member_idx]["data_publicacao_dt"],
                }
            )

        first_date = subset["data_publicacao_dt"].min()
        last_date = subset["data_publicacao_dt"].max()
        series_display_label = build_series_display_label(
            semantic_series_id=component_id,
            series_label=series_label,
            first_date=first_date,
            last_date=last_date,
            cluster_modes=cluster_modes,
            size=len(members),
        )
        summaries.append(
            {
                "semantic_series_id": component_id,
                "size": len(members),
                "first_date": first_date,
                "last_date": last_date,
                "span_days": (last_date - first_date).days if pd.notna(first_date) and pd.notna(last_date) else np.nan,
                "active_years": int(subset["ano"].nunique()),
                "cluster_modes": " | ".join(map(str, cluster_modes)),
                "operation_names": " | ".join(pd.Series(operation_names).value_counts().head(5).index.tolist()),
                "series_group_key": series_group_key,
                "series_label": series_label,
                "series_display_label": series_display_label,
                "crime_modes": " | ".join([label for label, _ in crime_labels.most_common(5)]),
                "sample_titles": " || ".join(title_examples),
            }
        )

    return pd.DataFrame(assignments), pd.DataFrame(summaries)


def consolidate_semantic_series(
    df: pd.DataFrame,
    assignments_df: pd.DataFrame,
    summaries_df: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if assignments_df.empty or summaries_df.empty:
        return assignments_df, summaries_df

    series_meta = summaries_df.copy()

    members = assignments_df[["link", "semantic_series_id"]].merge(
        series_meta[["semantic_series_id", "series_label", "series_group_key"]],
        on="semantic_series_id",
        how="left",
    ).merge(
        df[["link", "titulo", "data_publicacao_dt", "ano", "cluster_id", "nome_operacao", "crime_labels"]],
        on="link",
        how="left",
    )

    groups = []
    for _, subset in members.groupby(["series_group_key"], dropna=False):
        if subset.empty:
            continue

        subset = subset.sort_values("data_publicacao_dt")
        title_examples = subset["titulo"].dropna().head(3).tolist()
        operation_names = [name for name in subset["nome_operacao"].dropna().tolist() if name]
        crime_labels = Counter(label for labels in subset["crime_labels"] for label in labels)
        cluster_modes = subset["cluster_id"].mode().tolist()[:3]
        first_date = subset["data_publicacao_dt"].min()
        last_date = subset["data_publicacao_dt"].max()
        size = int(subset["link"].nunique())
        series_label = build_series_label(operation_names, crime_labels, title_examples, cluster_modes)
        series_group_key = str(subset["series_group_key"].iloc[0])
        groups.append(
            {
                "series_group_key": series_group_key,
                "series_label": series_label,
                "first_date": first_date,
                "last_date": last_date,
                "size": size,
                "active_years": int(subset["ano"].nunique()),
                "cluster_modes": " | ".join(map(str, cluster_modes)),
                "operation_names": " | ".join(pd.Series(operation_names).value_counts().head(5).index.tolist()),
                "crime_modes": " | ".join([label for label, _ in crime_labels.most_common(5)]),
                "sample_titles": " || ".join(title_examples),
                "links": subset["link"].drop_duplicates().tolist(),
            }
        )

    groups_df = pd.DataFrame(groups).sort_values(
        ["size", "first_date", "series_label"], ascending=[False, True, True]
    ).reset_index(drop=True)

    consolidated_summaries = []
    consolidated_assignments = []
    for new_id, row in enumerate(groups_df.itertuples(index=False), start=1):
        cluster_modes = [int(part) for part in str(row.cluster_modes).split(" | ") if str(part).strip()]
        series_display_label = build_series_display_label(
            semantic_series_id=new_id,
            series_label=row.series_label,
            first_date=row.first_date,
            last_date=row.last_date,
            cluster_modes=cluster_modes,
            size=int(row.size),
        )
        consolidated_summaries.append(
            {
                "semantic_series_id": new_id,
                "size": int(row.size),
                "first_date": row.first_date,
                "last_date": row.last_date,
                "span_days": (row.last_date - row.first_date).days if pd.notna(row.first_date) and pd.notna(row.last_date) else np.nan,
                "active_years": int(row.active_years),
                "cluster_modes": row.cluster_modes,
                "operation_names": row.operation_names,
                "series_group_key": row.series_group_key,
                "series_label": row.series_label,
                "series_display_label": series_display_label,
                "crime_modes": row.crime_modes,
                "sample_titles": row.sample_titles,
            }
        )
        for link in row.links:
            consolidated_assignments.append(
                {
                    "link": link,
                    "semantic_series_id": new_id,
                }
            )

    return pd.DataFrame(consolidated_assignments), pd.DataFrame(consolidated_summaries)


def build_unique_pairs(df: pd.DataFrame) -> pd.DataFrame:
    pairs = df.copy()
    pairs["pair_key"] = pairs.apply(
        lambda row: "||".join(sorted([str(row["source_link"]), str(row["target_link"])])),
        axis=1,
    )
    pairs = pairs.drop_duplicates(subset=["pair_key"], keep="first").drop(columns=["pair_key"]).reset_index(drop=True)
    return pairs


def build_series_label(operation_names: list[str], crime_labels: Counter, title_examples: list[str], cluster_modes: list[int]) -> str:
    if operation_names:
        return " | ".join(pd.Series(operation_names).value_counts().head(3).index.tolist())
    if crime_labels:
        top_crimes = [label for label, _ in crime_labels.most_common(2)]
        return f"serie_por_crime_{' | '.join(top_crimes)}"
    if title_examples:
        return title_examples[0][:90]
    if cluster_modes:
        return f"serie_cluster_{cluster_modes[0]}"
    return "serie_sem_nome"


def build_series_group_key(operation_names: list[str], crime_labels: Counter, series_label: str) -> str:
    if operation_names:
        top_operations = pd.Series(operation_names).value_counts().head(5).index.tolist()
        return f"operation::{normalize_label(' | '.join(top_operations))}"
    if crime_labels:
        top_crime_modes = [label for label, _ in crime_labels.most_common(5)]
        return f"crime::{normalize_label(' | '.join(top_crime_modes))}"
    return f"label::{normalize_label(series_label)}"


def build_series_display_label(
    semantic_series_id: int,
    series_label: str,
    first_date: pd.Timestamp,
    last_date: pd.Timestamp,
    cluster_modes: list[int],
    size: int,
) -> str:
    first_year = int(first_date.year) if pd.notna(first_date) else 0
    last_year = int(last_date.year) if pd.notna(last_date) else 0
    cluster_hint = f"c{cluster_modes[0]}" if cluster_modes else "c?"
    return f"{series_label} | {first_year}-{last_year} | {cluster_hint} | n={size} | id={semantic_series_id}"


def cluster_summary(df: pd.DataFrame, top_terms: dict[int, list[str]]) -> pd.DataFrame:
    rows = []
    geo_tag_keys = set(STATE_TAG_TO_UF.keys())
    geo_tag_keys |= {fold_text(item["capital"]) for item in BRAZIL_STATES}
    for cluster_id, subset in df.groupby("cluster_id"):
        tags = Counter()
        crimes = Counter()
        modus = Counter()
        states = Counter()
        for value in subset["tags"].fillna(""):
            for tag in [part.strip() for part in value.split("|") if part.strip()]:
                tag_key = fold_text(tag)
                if tag_key in geo_tag_keys:
                    continue
                tags[tag] += 1
        for labels in subset["crime_labels"]:
            crimes.update(labels)
        for labels in subset["modus_labels"]:
            modus.update(labels)
        for ufs in subset["ufs_mencionadas"]:
            states.update(ufs)

        first_date = subset["data_publicacao_dt"].min()
        last_date = subset["data_publicacao_dt"].max()
        rows.append(
            {
                "cluster_id": int(cluster_id),
                "size": len(subset),
                "first_date": first_date,
                "last_date": last_date,
                "active_years": int(subset["ano"].nunique()),
                "top_terms": " | ".join(top_terms.get(int(cluster_id), [])),
                "top_tags": " | ".join([tag for tag, _ in tags.most_common(8)]),
                "top_states": " | ".join([STATE_LOOKUP[uf]["state"] for uf, _ in states.most_common(6)]),
                "top_crimes": " | ".join([tag for tag, _ in crimes.most_common(6)]),
                "top_modus": " | ".join([tag for tag, _ in modus.most_common(6)]),
                "sample_titles": " || ".join(subset.sort_values("data_publicacao_dt")["titulo"].head(3).tolist()),
            }
        )
    summary = pd.DataFrame(rows).sort_values(["size", "cluster_id"], ascending=[False, True]).reset_index(drop=True)
    summary["cluster_label"] = summary.apply(
        lambda row: f"cluster_{row['cluster_id']}_{normalize_label(' '.join(str(row['top_terms']).split(' | ')[:4]))}",
        axis=1,
    )
    return summary


def temporal_recurrence(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for cluster_id, subset in df.groupby("cluster_id"):
        monthly_counts = subset.groupby("ano_mes").size().sort_index()
        month_of_year = subset.groupby("mes").size()
        sorted_dates = subset["data_publicacao_dt"].dropna().sort_values()
        gaps = sorted_dates.diff().dt.days.dropna()
        rows.append(
            {
                "cluster_id": int(cluster_id),
                "noticias": len(subset),
                "active_years": int(subset["ano"].nunique()),
                "active_months": int(monthly_counts.shape[0]),
                "peak_year_month": monthly_counts.idxmax() if not monthly_counts.empty else None,
                "peak_year_month_count": int(monthly_counts.max()) if not monthly_counts.empty else 0,
                "peak_calendar_month": int(month_of_year.idxmax()) if not month_of_year.empty else np.nan,
                "peak_calendar_month_count": int(month_of_year.max()) if not month_of_year.empty else 0,
                "peak_calendar_month_share": round(float(month_of_year.max() / len(subset)), 4) if not month_of_year.empty else np.nan,
                "median_gap_days": round(float(gaps.median()), 2) if not gaps.empty else np.nan,
                "mean_gap_days": round(float(gaps.mean()), 2) if not gaps.empty else np.nan,
                "repeats_across_years": bool(subset["ano"].nunique() >= 3),
            }
        )
    return pd.DataFrame(rows).sort_values(["repeats_across_years", "noticias"], ascending=[False, False]).reset_index(drop=True)


def summarize_labels(df: pd.DataFrame, column: str, prefix: str) -> pd.DataFrame:
    records = []
    for _, row in df.iterrows():
        for label in row[column]:
            records.append({"ano": row["ano"], f"{prefix}_label": label})
    summary = pd.DataFrame(records)
    if summary.empty:
        return pd.DataFrame(columns=["ano", f"{prefix}_label", "noticias"])
    return (
        summary.groupby(["ano", f"{prefix}_label"])
        .size()
        .reset_index(name="noticias")
        .sort_values(["ano", "noticias"], ascending=[True, False])
        .reset_index(drop=True)
    )


def summarize_states(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    exploded = (
        df[["ano", "cluster_id", "ufs_mencionadas"]]
        .explode("ufs_mencionadas")
        .dropna(subset=["ufs_mencionadas"])
        .rename(columns={"ufs_mencionadas": "uf"})
    )
    if exploded.empty:
        empty = pd.DataFrame(columns=["ano", "uf", "state", "lat", "lon", "noticias"])
        return empty, empty

    exploded["state"] = exploded["uf"].map(lambda uf: STATE_LOOKUP[uf]["state"])
    exploded["lat"] = exploded["uf"].map(lambda uf: STATE_LOOKUP[uf]["lat"])
    exploded["lon"] = exploded["uf"].map(lambda uf: STATE_LOOKUP[uf]["lon"])

    by_year = (
        exploded.groupby(["ano", "uf", "state", "lat", "lon"])
        .size()
        .reset_index(name="noticias")
        .sort_values(["ano", "noticias"], ascending=[True, False])
        .reset_index(drop=True)
    )
    by_cluster = (
        exploded.groupby(["cluster_id", "uf", "state", "lat", "lon"])
        .size()
        .reset_index(name="noticias")
        .sort_values(["cluster_id", "noticias"], ascending=[True, False])
        .reset_index(drop=True)
    )
    return by_year, by_cluster


def top_examples_by_label(df: pd.DataFrame, label_column: str, label_name: str, top_n: int = 3) -> list[str]:
    subset = df[df[label_column].map(lambda labels: label_name in labels)]
    if subset.empty:
        return []
    return subset.sort_values("data_publicacao_dt")["titulo"].head(top_n).tolist()


def write_report(
    output_file: Path,
    df: pd.DataFrame,
    neighbors_df: pd.DataFrame,
    cluster_df: pd.DataFrame,
    temporal_df: pd.DataFrame,
    crime_df: pd.DataFrame,
    modus_df: pd.DataFrame,
    series_df: pd.DataFrame,
) -> None:
    top_pairs = (
        neighbors_df.loc[neighbors_df["cosine_similarity"] >= 0.80]
        .sort_values("cosine_similarity", ascending=False)
        .pipe(build_unique_pairs)
        .head(10)
    )
    recurring_clusters = temporal_df[temporal_df["repeats_across_years"]].head(10)
    biggest_clusters = cluster_df.head(10)
    top_crimes = crime_df.groupby("crime_label")["noticias"].sum().sort_values(ascending=False).head(10)
    top_modus = modus_df.groupby("modus_label")["noticias"].sum().sort_values(ascending=False).head(10)
    top_series = series_df.head(10)

    lines = [
        "# Analise Qualitativa das Noticias de Operacoes da PF",
        "",
        f"- Base analisada: {len(df)} noticias",
        f"- Periodo coberto: {df['data_publicacao_dt'].min().date()} a {df['data_publicacao_dt'].max().date()}",
        f"- Clusters semanticos: {df['cluster_id'].nunique()}",
        f"- Series semanticas recorrentes: {len(series_df)}",
        "",
        "## O que este pipeline responde",
        "",
        "- Quais noticias sao semanticamente parecidas entre si",
        "- Quais grupos de atuacao se repetem ao longo do tempo",
        "- Quais crimes e modos de atuacao aparecem com mais frequencia",
        "- Quais series de noticias sugerem repeticao ou continuidade de padrao operacional",
        "- Onde as noticias se concentram por estado, sem misturar geografia com o vocabulario dos clusters",
        "",
        "## Maiores clusters",
        "",
    ]

    for _, row in biggest_clusters.iterrows():
        lines.append(
            f"- Cluster {int(row['cluster_id'])}: {int(row['size'])} noticias | termos: {row['top_terms']} | crimes: {row['top_crimes']} | estados: {row['top_states']}"
        )

    lines.extend(["", "## Pares com alta similaridade", ""])
    for _, row in top_pairs.iterrows():
        lines.append(
            f"- {row['source_titulo']} <-> {row['target_titulo']} | similaridade={row['cosine_similarity']:.3f} | gap_dias={row['gap_days']}"
        )

    lines.extend(["", "## Recorrencia temporal por cluster", ""])
    for _, row in recurring_clusters.iterrows():
        lines.append(
            f"- Cluster {int(row['cluster_id'])}: {int(row['noticias'])} noticias em {int(row['active_years'])} anos | pico={row['peak_year_month']} | mes_calendario_pico={int(row['peak_calendar_month']) if pd.notna(row['peak_calendar_month']) else 'NA'}"
        )

    lines.extend(["", "## Crimes mais presentes", ""])
    for label, count in top_crimes.items():
        examples = top_examples_by_label(df, "crime_labels", label)
        lines.append(f"- {label}: {int(count)} noticias | exemplos: {' || '.join(examples)}")

    lines.extend(["", "## Modus operandi mais presentes", ""])
    for label, count in top_modus.items():
        examples = top_examples_by_label(df, "modus_labels", label)
        lines.append(f"- {label}: {int(count)} noticias | exemplos: {' || '.join(examples)}")

    lines.extend(["", "## Series semanticas relevantes", ""])
    for _, row in top_series.iterrows():
        lines.append(
            f"- Serie {int(row['semantic_series_id'])}: {int(row['size'])} noticias | anos={int(row['active_years'])} | crimes={row['crime_modes']} | exemplos={row['sample_titles']}"
        )

    lines.extend([
        "",
        "## Sugestoes de exploracao adicional",
        "",
        "- Comparar a evolucao anual dos clusters de corrupcao, lavagem de dinheiro e crime ambiental",
        "- Medir quando um cluster muda de vocabulÃ¡rio ao longo dos anos para detectar adaptacao do crime",
        "- Isolar noticias com alta similaridade e grande distancia temporal para detectar repeticao de modus operandi",
        "- Criar uma rede de coocorrencia entre crimes e tags para identificar combinacoes frequentes",
        "- Separar operacoes com nome proprio recorrente para ver continuidade institucional da atuacao",
    ])

    output_file.write_text("\n".join(lines), encoding="utf-8")


def run_analysis(args: argparse.Namespace) -> AnalysisArtifacts:
    output_dir = args.output_dir
    ensure_dir(output_dir)

    df = load_corpus(args.index_csv, args.content_csv)
    vectorizer, tfidf_matrix, embeddings = build_semantic_space(df["texto_ponderado"], random_state=args.random_state)
    df["cluster_id"] = assign_clusters(embeddings, random_state=args.random_state)

    top_terms = top_terms_by_cluster(tfidf_matrix, vectorizer, df["cluster_id"].to_numpy())
    cluster_df = cluster_summary(df, top_terms=top_terms)
    label_map = dict(zip(cluster_df["cluster_id"], cluster_df["cluster_label"]))
    df["cluster_label"] = df["cluster_id"].map(label_map)

    neighbors_df = nearest_neighbors(df, embeddings, n_neighbors=args.neighbors)
    recurring_pairs = neighbors_df[
        (neighbors_df["gap_days"].fillna(0) >= 30)
        & (neighbors_df["same_cluster"])
        & (
            (neighbors_df["cosine_similarity"] >= max(args.series_threshold, 0.90))
            | (
                neighbors_df["source_operation_name"].fillna("").ne("")
                & (neighbors_df["source_operation_name"] == neighbors_df["target_operation_name"])
                & (neighbors_df["cosine_similarity"] >= args.series_threshold)
            )
        )
    ].sort_values(["cosine_similarity", "gap_days"], ascending=[False, False]).reset_index(drop=True)
    recurring_pairs = build_unique_pairs(recurring_pairs)

    series_assignments, series_summary = semantic_series(df, recurring_pairs)
    series_assignments, series_summary = consolidate_semantic_series(df, series_assignments, series_summary)
    if not series_assignments.empty:
        df = df.merge(series_assignments[["link", "semantic_series_id"]], on="link", how="left")
    else:
        df["semantic_series_id"] = np.nan

    temporal_df = temporal_recurrence(df)
    crime_df = summarize_labels(df, column="crime_labels", prefix="crime")
    modus_df = summarize_labels(df, column="modus_labels", prefix="modus")
    states_year_df, states_cluster_df = summarize_states(df)

    corpus_output = output_dir / "corpus_enriquecido.csv"
    neighbors_output = output_dir / "vizinhos_semelhantes.csv"
    recurring_pairs_output = output_dir / "pares_recorrentes.csv"
    cluster_output = output_dir / "resumo_clusters.csv"
    temporal_output = output_dir / "recorrencia_temporal.csv"
    crime_output = output_dir / "crimes_por_ano.csv"
    modus_output = output_dir / "modus_operandi_por_ano.csv"
    series_output = output_dir / "series_semanticas.csv"
    cluster_year_output = output_dir / "clusters_por_ano.csv"
    states_year_output = output_dir / "estados_por_ano.csv"
    states_cluster_output = output_dir / "estados_por_cluster.csv"
    report_output = output_dir / "analise_qualitativa.md"

    df[
        [
            "link", "titulo", "subtitulo", "data_publicacao_dt", "ano", "mes", "ano_mes", "tags",
            "nome_operacao", "cluster_id", "cluster_label", "semantic_series_id", "crime_labels", "modus_labels",
            "ufs_mencionadas", "estados_mencionados", "texto_busca_normalizado", "markdown_path",
        ]
    ].to_csv(corpus_output, index=False, encoding="utf-8-sig")
    neighbors_df.to_csv(neighbors_output, index=False, encoding="utf-8-sig")
    recurring_pairs.to_csv(recurring_pairs_output, index=False, encoding="utf-8-sig")
    cluster_df.to_csv(cluster_output, index=False, encoding="utf-8-sig")
    temporal_df.to_csv(temporal_output, index=False, encoding="utf-8-sig")
    crime_df.to_csv(crime_output, index=False, encoding="utf-8-sig")
    modus_df.to_csv(modus_output, index=False, encoding="utf-8-sig")
    series_summary.to_csv(series_output, index=False, encoding="utf-8-sig")
    states_year_df.to_csv(states_year_output, index=False, encoding="utf-8-sig")
    states_cluster_df.to_csv(states_cluster_output, index=False, encoding="utf-8-sig")

    (
        df.groupby(["ano", "cluster_id", "cluster_label"])
        .size()
        .reset_index(name="noticias")
        .sort_values(["ano", "noticias"], ascending=[True, False])
        .to_csv(cluster_year_output, index=False, encoding="utf-8-sig")
    )

    write_report(
        output_file=report_output,
        df=df,
        neighbors_df=neighbors_df,
        cluster_df=cluster_df,
        temporal_df=temporal_df,
        crime_df=crime_df,
        modus_df=modus_df,
        series_df=series_summary,
    )

    return AnalysisArtifacts(
        corpus=df,
        neighbors=neighbors_df,
        recurring_pairs=recurring_pairs,
        cluster_summary=cluster_df,
        temporal_summary=temporal_df,
        crime_summary=crime_df,
        modus_summary=modus_df,
        semantic_series=series_summary,
    )


def main() -> None:
    args = parse_args()
    artifacts = run_analysis(args)
    print(f"[analysis] noticias: {len(artifacts.corpus)}")
    print(f"[analysis] clusters: {artifacts.corpus['cluster_id'].nunique()}")
    print(f"[analysis] series_semanticas: {len(artifacts.semantic_series)}")
    print(f"[analysis] saida: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
